#include "calculator.h"

float add(float x, float y)
{
    return x + y;
}

int add(int x, int y)
{
    return x + y;
}
