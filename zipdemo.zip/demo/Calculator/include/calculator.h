#pragma once
#include "dllexports.h"

DLL_PUBLIC float add(float x, float y);
DLL_PUBLIC int   add(int x, int y);
